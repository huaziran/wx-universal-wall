const app = getApp()
const db = wx.cloud.database();
let id = ''
Page({
  data: {
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function () {
    let that = this
    // 查看是否授权
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.userInfo']) {
          //用户已经授权过
        
    
        }
      }
    })

    wx.cloud.callFunction({
      name: 'add',
      success(res) {
        console.log("获取云数据id成功", res)
        getApp().globalData.openId = res.result.openid
        id = res.result.openid
      },
      fail(res) {
        console.log("获取数据失败", res)
      }

    })

    setTimeout(function () {
      wx.hideLoading()
    }, 1000)


    

  },


  bindGetUserInfo: function (e) {
    console.log(e);
    if (e.detail.userInfo) {

      db.collection('userInfo').add({
        data: {
          userInfo: e.detail.userInfo
        }
      })
        .then(res => {
          console.log("上传个人信息成功", res)
        })
        .catch(res => {
          console.log("上传个人信息失败", res)
        })

   

      wx.showModal({
        title: '使用规则',
        content: "  1.	表白墙欢迎真心表白、寻人寻物等，但拒绝小广告或者不文明词句哦！请大家一起维护表白墙，让它成为大家倾吐心事的一片净土。2.	墙墙真心希望能有更多的小伙伴通过表白墙找到自己的幸福并牢牢抓住，希望你们都能勇敢些。毕竟主动点，你们就可能有故事。3.	墙墙欢迎大胆的你“自荐”，也欢迎“忧国忧民”的你为室友发声。勇敢点，说不定真爱就在眼前。4.	卖舍友拒绝黑照以及不文明的语言哦，希望大家都能尊重他人。5.	希望还未找到幸福的你，能够通过墙墙，找到你丢失的那一半，并且小心爱护，牵手一直走下去。                                                      ",
      
        showCancel: false,

        complete() {
          db.collection('userInfo')
            .where({
              _openid: id
            })
            .get({
              success: function (res) {
                console.log("获取用户数据成功", res)
                getApp().globalData.userInfo = res.data[0].userInfo;
                if (app) {
                  wx.switchTab({
                    url: '/pages/index/index'
                  })
                } else {
                  wx.hideToast({
                    title: '加载中'
                  })
                }
              },
              fail: function (res) {
                console.log("获取用户数据失败", res)
              }
            })

        }

      })

    } else {
      //用户按了拒绝按钮
      wx.showModal({
        title: '警告',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击了“返回授权”')
          }
        }
      })
    }

  },

  onShow: function () {
    //  this.queryUsreInfo()
    this.onLoad()
  },


})